package Login;

import static org.junit.Assert.assertEquals;

import com.cg.login.Login;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinationLogin {
 private Login log;
 
 
@Given("^user has username and password credentials and want to login$")
public void user_has_username_and_password_credentials_and_want_to_login() throws Throwable {
    log = new Login("capg","capg123", 0);
   // throw new PendingException();
}

@When("^user enters username and password and clicks on login button$")
public void user_enters_username_and_password_and_clicks_on_login_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	assertEquals(log.getUserName(), "capg");
	assertEquals(log.getPassword(), "capg123");
   // throw new PendingException();
}

@Then("^System displays welcome message$")
public void system_displays_welcome_message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   // throw new PendingException();
	System.out.println("Welcome");
	
}
@When("^user enters valid username$")
public void user_enters_valid_username() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	assertEquals(log.getUserName(), "capg");

    //throw new PendingException();
}

@When("^user enters wrong password$")
public void user_enters_wrong_password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	assertEquals(log.getPassword(), "capg123");

    //throw new PendingException();
}

@Then("^System displays error message$")
public void system_displays_error_message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	System.out.println("Please insert valid password");
}
@When("^user enter (\\d+)$")
public void user_enter(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   // throw new PendingException();
	log.setAge(arg1);
}

@Then("^Check age and login is possible if age>(\\d+)$")
public void check_age_and_login_is_possible_if_age(int arg1) throws Throwable {
	if(log.getAge()>=18)
	{
		System.out.println("Valid");
	}
	else
		System.out.println("Invalid");
    // Write code here that turns the phrase above into concrete actions
  //  throw new PendingException();
}

}
